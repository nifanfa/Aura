\Dir Testing\
\test\
\test\DirInTest\
\test\DirInTest\Readme.txt -> contains 40 bytes of text
\Kudzu.txt -> contains 12 bytes of text
\Root.txt -> contains 5 bytes of text
